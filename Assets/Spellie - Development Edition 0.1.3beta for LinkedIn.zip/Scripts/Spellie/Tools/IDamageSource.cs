﻿namespace Spellie.Tools
{
    public interface IDamageSource
    {
        
    }
}
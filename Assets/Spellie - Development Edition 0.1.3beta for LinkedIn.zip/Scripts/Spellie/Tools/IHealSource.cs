﻿namespace Spellie.Tools
{
    public interface IHealSource
    {
        
    }
}
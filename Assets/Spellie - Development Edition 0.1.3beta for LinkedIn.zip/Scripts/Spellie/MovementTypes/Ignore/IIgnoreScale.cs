﻿namespace Spellie.MovementTypes.Ignore
{
    public interface IIgnoreScale
    {
        
    }
}
﻿namespace Spellie.MovementTypes.Ignore
{
    public interface IIgnoreMovement : IIgnorePosition, IIgnoreRotation, IIgnoreScale
    {
        
    }
}
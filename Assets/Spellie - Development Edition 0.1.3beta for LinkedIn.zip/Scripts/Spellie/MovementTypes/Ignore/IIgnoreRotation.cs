﻿namespace Spellie.MovementTypes.Ignore
{
    public interface IIgnoreRotation
    {
        
    }
}
﻿namespace Spellie.MovementTypes.Ignore
{
    public interface IIgnorePosition
    {
        
    }
}
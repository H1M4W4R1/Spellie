﻿using Spellie.Affiinities;
using Spellie.Affiinities.Attributes;

namespace Spellie.Samples.Affinities
{
    [AffinityDamageMultiplier(typeof(EarthAffinity), 2f)]
    public class AirAffinity : SpellieAffinity
    {
        
    }
}
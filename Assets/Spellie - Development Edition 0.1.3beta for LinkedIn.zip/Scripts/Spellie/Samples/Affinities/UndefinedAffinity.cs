﻿using Spellie.Affiinities;

namespace Spellie.Samples.Affinities
{
    public class UndefinedAffinity : SpellieAffinity
    {
        
    }
}